print(Sys.time())
options(scipen=999)

library(data.table)
library(dplyr)
library(stringr)
library(splitstackshape)
library(lazyeval)

setwd("/home/ubuntu/data/Project/temp/")



Inq_Attr_Final <- data.frame()
for(file in list.files()) {
  
  df <- read.table(file, sep = "|",header=T,colClasses=c("LOS.APP.ID"="character"),
                   fill=T )
  print(nrow(df))
  
  if(nrow(Inq_Attr_Final) == 0){
    
    Inq_Attr_Final <- df
    
  } else {
    
    Inq_Attr_Final<-merge(Inq_Attr_Final, df, by="CREDT.RPT.ID", all=T)
    print(nrow(Inq_Attr_Final))
    
  }
  
}

Inq_Attr_Final<-Inq_Attr_Final[Inq_Attr_Final$CREDT.RPT.ID!="CREDT-RPT-ID",]

write.table(Inq_Attr_Final,"/home/ubuntu/data/Project/Output/Inquiry_Attributes_Script.csv",sep="|",row.names = FALSE)

print(Sys.time())
gc()
rm(list=ls(all=TRUE))
