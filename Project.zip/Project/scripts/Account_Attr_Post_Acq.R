print(Sys.time())
options(scipen=999)

memory.limit(8000)

library(data.table)
library(plyr)
library(dplyr)
library(stringr)
library(splitstackshape)
library(lazyeval)
library(tcltk)
library(zoo)
library(Rserve)
Rserve()


##the function that returns the path of the script that is called.
##used to determine the path of the executing program
get_scriptpath <- function() {
  # location of script can depend on how it was invoked:
  # source() and knit() put it in sys.calls()
  path <- NULL
  
  if(!is.null(sys.calls())) {
    # get name of script - hope this is consisitent!
    path <- as.character(sys.call(1))[2] 
    # make sure we got a file that ends in .R, .Rmd or .Rnw
    if (grepl("..+\\.[R|Rmd|Rnw]", path, perl=TRUE, ignore.case = TRUE) )  {
      return(path)
    } else { 
      message("Obtained value for path does not end with .R, .Rmd or .Rnw: ", path)
    }
  } else{
    # Rscript and R -f put it in commandArgs
    args <- commandArgs(trailingOnly = FALSE)
  }
  return(path)
}

## args <- commandArgs()
## print(args);

##find the script path
mypath <- get_scriptpath()

##get the current path, set it and navigate to download folder to get ready to read the files
DIR <- dirname(mypath)
setwd(DIR)
setwd("/home/ubuntu/data/Project/Input")


output_name <- paste("Account_Attr_Post_Acq",".csv", sep = "" )

dataprep<-function(d)
{
  ##deleted written strings from DAS...HIST columns
  d$DAS...HIST<-gsub("(.{3})", "\\1 ", d$DAS...HIST)
  d$DPD...HIST<-gsub("(.{3})", "\\1 ", d$DPD...HIST)
  d$ASSET.CLASS...HIST<-gsub("(.{3})", "\\1 ", d$ASSET.CLASS...HIST)
  d<-concat.split.multiple(d, split.col="ASSET.CLASS...HIST", sep=" ")
  
  ## splits specified columns rergarding space seperators 
  d<-concat.split.multiple(d, split.col="DPD...HIST", sep=" ")
  
  d<-concat.split.multiple(d, split.col="DAS...HIST", sep=" ")
  d<-concat.split.multiple(d, split.col="AMT.OVERDUE...HIST", sep=",")   
  d<-concat.split.multiple(d, split.col="HIGH.CRD...HIST", sep=",") 
  d<-concat.split.multiple(d, split.col="CUR.BAL...HIST", sep=",")
  
  #colnames(d)[25]<-"REPORTED.DATE...HIST" 
  d<-concat.split.multiple(d, split.col="REPORTED.DATE...HIST", sep=",")
  
  #formats the data in columns
  d$REPORTED.DATE...HIST_01<-format(as.Date.character(d$REPORTED.DATE...HIST_01,"%Y%m%d"),format="%Y:%b")
  d$REPORTED.DATE...HIST_02<-format(as.Date.character(d$REPORTED.DATE...HIST_02,"%Y%m%d"),format="%Y:%b")
  d$REPORTED.DATE...HIST_03<-format(as.Date.character(d$REPORTED.DATE...HIST_03,"%Y%m%d"),format="%Y:%b")
  d$REPORTED.DATE...HIST_04<-format(as.Date.character(d$REPORTED.DATE...HIST_04,"%Y%m%d"),format="%Y:%b")
  d$REPORTED.DATE...HIST_05<-format(as.Date.character(d$REPORTED.DATE...HIST_05,"%Y%m%d"),format="%Y:%b")
  d$REPORTED.DATE...HIST_06<-format(as.Date.character(d$REPORTED.DATE...HIST_06,"%Y%m%d"),format="%Y:%b")
  d$REPORTED.DATE...HIST_07<-format(as.Date.character(d$REPORTED.DATE...HIST_07,"%Y%m%d"),format="%Y:%b")
  d$REPORTED.DATE...HIST_08<-format(as.Date.character(d$REPORTED.DATE...HIST_08,"%Y%m%d"),format="%Y:%b")
  d$REPORTED.DATE...HIST_09<-format(as.Date.character(d$REPORTED.DATE...HIST_09,"%Y%m%d"),format="%Y:%b")
  d$REPORTED.DATE...HIST_10<-format(as.Date.character(d$REPORTED.DATE...HIST_10,"%Y%m%d"),format="%Y:%b")
  d$REPORTED.DATE...HIST_11<-format(as.Date.character(d$REPORTED.DATE...HIST_11,"%Y%m%d"),format="%Y:%b")
  d$REPORTED.DATE...HIST_12<-format(as.Date.character(d$REPORTED.DATE...HIST_12,"%Y%m%d"),format="%Y:%b")
  d$REPORTED.DATE...HIST_13<-format(as.Date.character(d$REPORTED.DATE...HIST_13,"%Y%m%d"),format="%Y:%b")
  d$REPORTED.DATE...HIST_14<-format(as.Date.character(d$REPORTED.DATE...HIST_14,"%Y%m%d"),format="%Y:%b")
  d$REPORTED.DATE...HIST_15<-format(as.Date.character(d$REPORTED.DATE...HIST_15,"%Y%m%d"),format="%Y:%b")
  d$REPORTED.DATE...HIST_16<-format(as.Date.character(d$REPORTED.DATE...HIST_16,"%Y%m%d"),format="%Y:%b")
  d$REPORTED.DATE...HIST_17<-format(as.Date.character(d$REPORTED.DATE...HIST_17,"%Y%m%d"),format="%Y:%b")
  d$REPORTED.DATE...HIST_18<-format(as.Date.character(d$REPORTED.DATE...HIST_18,"%Y%m%d"),format="%Y:%b")
  d$REPORTED.DATE...HIST_19<-format(as.Date.character(d$REPORTED.DATE...HIST_19,"%Y%m%d"),format="%Y:%b")
  d$REPORTED.DATE...HIST_20<-format(as.Date.character(d$REPORTED.DATE...HIST_20,"%Y%m%d"),format="%Y:%b")
  d$REPORTED.DATE...HIST_21<-format(as.Date.character(d$REPORTED.DATE...HIST_21,"%Y%m%d"),format="%Y:%b")
  d$REPORTED.DATE...HIST_22<-format(as.Date.character(d$REPORTED.DATE...HIST_22,"%Y%m%d"),format="%Y:%b")
  d$REPORTED.DATE...HIST_23<-format(as.Date.character(d$REPORTED.DATE...HIST_23,"%Y%m%d"),format="%Y:%b")
  d$REPORTED.DATE...HIST_24<-format(as.Date.character(d$REPORTED.DATE...HIST_24,"%Y%m%d"),format="%Y:%b")
  d$REPORTED.DATE...HIST_25<-format(as.Date.character(d$REPORTED.DATE...HIST_25,"%Y%m%d"),format="%Y:%b")
  d$REPORTED.DATE...HIST_26<-format(as.Date.character(d$REPORTED.DATE...HIST_26,"%Y%m%d"),format="%Y:%b")
  d$REPORTED.DATE...HIST_27<-format(as.Date.character(d$REPORTED.DATE...HIST_27,"%Y%m%d"),format="%Y:%b")
  d$REPORTED.DATE...HIST_28<-format(as.Date.character(d$REPORTED.DATE...HIST_28,"%Y%m%d"),format="%Y:%b")
  d$REPORTED.DATE...HIST_29<-format(as.Date.character(d$REPORTED.DATE...HIST_29,"%Y%m%d"),format="%Y:%b")
  d$REPORTED.DATE...HIST_30<-format(as.Date.character(d$REPORTED.DATE...HIST_30,"%Y%m%d"),format="%Y:%b")
  d$REPORTED.DATE...HIST_31<-format(as.Date.character(d$REPORTED.DATE...HIST_31,"%Y%m%d"),format="%Y:%b")
  d$REPORTED.DATE...HIST_32<-format(as.Date.character(d$REPORTED.DATE...HIST_32,"%Y%m%d"),format="%Y:%b")
  d$REPORTED.DATE...HIST_33<-format(as.Date.character(d$REPORTED.DATE...HIST_33,"%Y%m%d"),format="%Y:%b")
  d$REPORTED.DATE...HIST_34<-format(as.Date.character(d$REPORTED.DATE...HIST_34,"%Y%m%d"),format="%Y:%b")
  d$REPORTED.DATE...HIST_35<-format(as.Date.character(d$REPORTED.DATE...HIST_35,"%Y%m%d"),format="%Y:%b")
  d$REPORTED.DATE...HIST_36<-format(as.Date.character(d$REPORTED.DATE...HIST_36,"%Y%m%d"),format="%Y:%b")
  
  ##brings dates in target columns
  d$PYMT.HIST_01<-paste(d$REPORTED.DATE...HIST_01,",",d$DPD...HIST_01,"/",d$ASSET.CLASS...HIST_01,sep="")
  d$PYMT.HIST_02<-paste(d$REPORTED.DATE...HIST_02,",",d$DPD...HIST_02,"/",d$ASSET.CLASS...HIST_02,sep="")
  d$PYMT.HIST_03<-paste(d$REPORTED.DATE...HIST_03,",",d$DPD...HIST_03,"/",d$ASSET.CLASS...HIST_03,sep="")
  d$PYMT.HIST_04<-paste(d$REPORTED.DATE...HIST_04,",",d$DPD...HIST_04,"/",d$ASSET.CLASS...HIST_04,sep="")
  d$PYMT.HIST_05<-paste(d$REPORTED.DATE...HIST_05,",",d$DPD...HIST_05,"/",d$ASSET.CLASS...HIST_05,sep="")
  d$PYMT.HIST_06<-paste(d$REPORTED.DATE...HIST_06,",",d$DPD...HIST_06,"/",d$ASSET.CLASS...HIST_06,sep="")
  d$PYMT.HIST_07<-paste(d$REPORTED.DATE...HIST_07,",",d$DPD...HIST_07,"/",d$ASSET.CLASS...HIST_07,sep="")
  d$PYMT.HIST_08<-paste(d$REPORTED.DATE...HIST_08,",",d$DPD...HIST_08,"/",d$ASSET.CLASS...HIST_08,sep="")
  d$PYMT.HIST_09<-paste(d$REPORTED.DATE...HIST_09,",",d$DPD...HIST_09,"/",d$ASSET.CLASS...HIST_09,sep="")
  d$PYMT.HIST_10<-paste(d$REPORTED.DATE...HIST_10,",",d$DPD...HIST_10,"/",d$ASSET.CLASS...HIST_10,sep="")
  d$PYMT.HIST_11<-paste(d$REPORTED.DATE...HIST_11,",",d$DPD...HIST_11,"/",d$ASSET.CLASS...HIST_11,sep="")
  d$PYMT.HIST_12<-paste(d$REPORTED.DATE...HIST_12,",",d$DPD...HIST_12,"/",d$ASSET.CLASS...HIST_12,sep="")
  d$PYMT.HIST_13<-paste(d$REPORTED.DATE...HIST_13,",",d$DPD...HIST_13,"/",d$ASSET.CLASS...HIST_13,sep="")
  d$PYMT.HIST_14<-paste(d$REPORTED.DATE...HIST_14,",",d$DPD...HIST_14,"/",d$ASSET.CLASS...HIST_14,sep="")
  d$PYMT.HIST_15<-paste(d$REPORTED.DATE...HIST_15,",",d$DPD...HIST_15,"/",d$ASSET.CLASS...HIST_15,sep="")
  d$PYMT.HIST_16<-paste(d$REPORTED.DATE...HIST_16,",",d$DPD...HIST_16,"/",d$ASSET.CLASS...HIST_16,sep="")
  d$PYMT.HIST_17<-paste(d$REPORTED.DATE...HIST_17,",",d$DPD...HIST_17,"/",d$ASSET.CLASS...HIST_17,sep="")
  d$PYMT.HIST_18<-paste(d$REPORTED.DATE...HIST_18,",",d$DPD...HIST_18,"/",d$ASSET.CLASS...HIST_18,sep="")
  d$PYMT.HIST_19<-paste(d$REPORTED.DATE...HIST_19,",",d$DPD...HIST_19,"/",d$ASSET.CLASS...HIST_19,sep="")
  d$PYMT.HIST_20<-paste(d$REPORTED.DATE...HIST_20,",",d$DPD...HIST_20,"/",d$ASSET.CLASS...HIST_20,sep="")
  d$PYMT.HIST_21<-paste(d$REPORTED.DATE...HIST_21,",",d$DPD...HIST_21,"/",d$ASSET.CLASS...HIST_21,sep="")
  d$PYMT.HIST_22<-paste(d$REPORTED.DATE...HIST_22,",",d$DPD...HIST_22,"/",d$ASSET.CLASS...HIST_22,sep="")
  d$PYMT.HIST_23<-paste(d$REPORTED.DATE...HIST_23,",",d$DPD...HIST_23,"/",d$ASSET.CLASS...HIST_23,sep="")
  d$PYMT.HIST_24<-paste(d$REPORTED.DATE...HIST_24,",",d$DPD...HIST_24,"/",d$ASSET.CLASS...HIST_24,sep="")
  d$PYMT.HIST_25<-paste(d$REPORTED.DATE...HIST_25,",",d$DPD...HIST_25,"/",d$ASSET.CLASS...HIST_25,sep="")
  d$PYMT.HIST_26<-paste(d$REPORTED.DATE...HIST_26,",",d$DPD...HIST_26,"/",d$ASSET.CLASS...HIST_26,sep="")
  d$PYMT.HIST_27<-paste(d$REPORTED.DATE...HIST_27,",",d$DPD...HIST_27,"/",d$ASSET.CLASS...HIST_27,sep="")
  d$PYMT.HIST_28<-paste(d$REPORTED.DATE...HIST_28,",",d$DPD...HIST_28,"/",d$ASSET.CLASS...HIST_28,sep="")
  d$PYMT.HIST_29<-paste(d$REPORTED.DATE...HIST_29,",",d$DPD...HIST_29,"/",d$ASSET.CLASS...HIST_29,sep="")
  d$PYMT.HIST_30<-paste(d$REPORTED.DATE...HIST_30,",",d$DPD...HIST_30,"/",d$ASSET.CLASS...HIST_30,sep="")
  d$PYMT.HIST_31<-paste(d$REPORTED.DATE...HIST_31,",",d$DPD...HIST_31,"/",d$ASSET.CLASS...HIST_31,sep="")
  d$PYMT.HIST_32<-paste(d$REPORTED.DATE...HIST_32,",",d$DPD...HIST_32,"/",d$ASSET.CLASS...HIST_32,sep="")
  d$PYMT.HIST_33<-paste(d$REPORTED.DATE...HIST_33,",",d$DPD...HIST_33,"/",d$ASSET.CLASS...HIST_33,sep="")
  d$PYMT.HIST_34<-paste(d$REPORTED.DATE...HIST_34,",",d$DPD...HIST_34,"/",d$ASSET.CLASS...HIST_34,sep="")
  d$PYMT.HIST_35<-paste(d$REPORTED.DATE...HIST_35,",",d$DPD...HIST_35,"/",d$ASSET.CLASS...HIST_35,sep="")
  d$PYMT.HIST_36<-paste(d$REPORTED.DATE...HIST_36,",",d$DPD...HIST_36,"/",d$ASSET.CLASS...HIST_36,sep="")
  
  ##splits columns by comma
  d<-concat.split.multiple(d, split.col="AMT.PAID...HIST", sep=",")  
  
  ##replaces NAs with most recent non-NA in all columns
  autofill<-function(d)
  {
    
    d<-t(d)
    library(zoo)
    d<-na.locf(d,fromLast = TRUE)
    d<-t(d)
    d<-as.data.frame(d)
  }  
  
  ##if any NAs remains replaces them with zeros
  zerofill<-function(d)
  {
    d[is.na(d)]<-0
    d<-as.data.frame(d)
  }
  d<-as.data.frame(d)
  
  
  ##corrects the column names
  overdue<-c("AMT.OVERDUE...HIST_01","AMT.OVERDUE...HIST_02","AMT.OVERDUE...HIST_03","AMT.OVERDUE...HIST_04",
             "AMT.OVERDUE...HIST_05","AMT.OVERDUE...HIST_06","AMT.OVERDUE...HIST_07","AMT.OVERDUE...HIST_08","AMT.OVERDUE...HIST_09","AMT.OVERDUE...HIST_10","AMT.OVERDUE...HIST_11","AMT.OVERDUE...HIST_12",
             "AMT.OVERDUE...HIST_13","AMT.OVERDUE...HIST_14","AMT.OVERDUE...HIST_15","AMT.OVERDUE...HIST_16","AMT.OVERDUE...HIST_17","AMT.OVERDUE...HIST_18","AMT.OVERDUE...HIST_19","AMT.OVERDUE...HIST_20")
  vars1<-names(d)%in%overdue
  
  hrd<-c("HIGH.CRD...HIST_01","HIGH.CRD...HIST_02","HIGH.CRD...HIST_03","HIGH.CRD...HIST_04",
         "HIGH.CRD...HIST_05","HIGH.CRD...HIST_06","HIGH.CRD...HIST_07","HIGH.CRD...HIST_08","HIGH.CRD...HIST_09","HIGH.CRD...HIST_10","HIGH.CRD...HIST_11","HIGH.CRD...HIST_12",
         "HIGH.CRD...HIST_13","HIGH.CRD...HIST_14","HIGH.CRD...HIST_15","HIGH.CRD...HIST_16","HIGH.CRD...HIST_17","HIGH.CRD...HIST_18","HIGH.CRD...HIST_19","HIGH.CRD...HIST_20")
  
  vars2<-names(d)%in%hrd
  
  amd<-c("AMT.PAID...HIST_01","AMT.PAID...HIST_02","AMT.PAID...HIST_03","AMT.PAID...HIST_04",
         "AMT.PAID...HIST_05","AMT.PAID...HIST_06","AMT.PAID...HIST_07","AMT.PAID...HIST_08","AMT.PAID...HIST_09","AMT.PAID...HIST_10","AMT.PAID...HIST_11","AMT.PAID...HIST_12",
         "AMT.PAID...HIST_13","AMT.PAID...HIST_14","AMT.PAID...HIST_15","AMT.PAID...HIST_16","AMT.PAID...HIST_17","AMT.PAID...HIST_18","AMT.PAID...HIST_19","AMT.PAID...HIST_20")
  
  vars3<-names(d)%in%amd
  
  crd<-c("CUR.BAL...HIST_01","CUR.BAL...HIST_02","CUR.BAL...HIST_03","CUR.BAL...HIST_04",
         "CUR.BAL...HIST_05","CUR.BAL...HIST_06","CUR.BAL...HIST_07","CUR.BAL...HIST_08","CUR.BAL...HIST_09","CUR.BAL...HIST_10","CUR.BAL...HIST_11","CUR.BAL...HIST_12",
         "CUR.BAL...HIST_13","CUR.BAL...HIST_14","CUR.BAL...HIST_15","CUR.BAL...HIST_16","CUR.BAL...HIST_17","CUR.BAL...HIST_18","CUR.BAL...HIST_19","CUR.BAL...HIST_20")
  
  vars4<-names(d)%in%crd
  
  ##changes the functions with their corrected counterparts
  d[,vars1]<-zerofill(d[,vars1])
  d[,vars2]<-autofill(d[,vars2])
  d[,vars3]<-autofill(d[,vars3])
  d[,vars4]<-autofill(d[,vars4])
  
  print(Sys.time())
  
  return(d)
}

s<-function(d)
{
  ##finds the slope by dividing CUR.BAL 10+11+12 with 1+2+3
  Balance_Slope<-function(d)
  {
    d$balnceslope<-(d$CUR.BAL...HIST_12+d$CUR.BAL...HIST_11+d$CUR.BAL...HIST_10)/(d$CUR.BAL...HIST_01+d$CUR.BAL...HIST_02+d$CUR.BAL...HIST_03)*100
    d3<-as.data.frame(d$balnceslope)
    d1<-as.data.frame(d$key)
    act<-cbind(d1,d3)
    colnames(act) <- c(  "KEY", " BALANCE_SLOPE")
    return(act)
  }
  BALANCE_SLOPE<-Balance_Slope(d)
  
  
  ##finds the pay ratio by dividing AMT.PAID 1 + 2 + 3 and CUR.BAL 2+ 3 + 4
  praccount<-function(d)
  {
    
    q<-(d$AMT.PAID...HIST_01+d$AMT.PAID...HIST_02+d$AMT.PAID...HIST_03)/(d$CUR.BAL...HIST_02+d$CUR.BAL...HIST_03+d$CUR.BAL...HIST_04)
    d1<-as.data.frame(d$key)
    act<-cbind(d1,q)
    colnames(act) <- c("KEY", "PAY_RATIO")
    return(act)
  }
  PAYRATIO<-praccount(d)
  
  ## credit trend by geting HIGH.CRD variable and applying linear regression
  credit_trend<-function(d)
  {
    d<-within(d,crtwl<-paste(HIGH.CRD...HIST_01,HIGH.CRD...HIST_02,HIGH.CRD...HIST_03,HIGH.CRD...HIST_04,HIGH.CRD...HIST_05,HIGH.CRD...HIST_06,
                             HIGH.CRD...HIST_07,HIGH.CRD...HIST_08,HIGH.CRD...HIST_09,HIGH.CRD...HIST_10,HIGH.CRD...HIST_11,HIGH.CRD...HIST_12,sep=","))
    one = c(1:12)
    d$m<-paste(as.character(one), collapse=", ")
    SLOPE<-function(data.frame=d,x,y)
    {
      var<-as.numeric(unlist(strsplit(x, split=",")))
      a<-cbind(var)
      a[is.na(a)]<-0
      k<-t(a)
      var<-as.numeric(k)
      mnth<-as.numeric(unlist(strsplit(y,split=",")))
      j<-cbind(var,mnth)
      l<-lm(j[,1]~j[,2],d)
      q<-l$coefficients[2]
      return(q)
    }
    
    for(i in 1:nrow(d))
    {
      d$cretre[i]<-SLOPE(d,d$crtwl[i],d$m[i])
    }
    d3<-as.data.frame(d$cretre)
    d1<-as.data.frame(d$key)
    act<-cbind(d1,d3)
    colnames(act) <- c("KEY","CREDIT_LIMIT_SLOPE_12MNTHS")
    return(act)
    
  }
  CREDIT_LIMIT_TREND<-credit_trend(d)
  
  ## finds balance build up by comparing balance situations of two sequential months
  Balance_buildup<-function(d)
  {
    d<-d[d$ACCT.TYPE=="Credit Card",]
    BBL<-function(d)
    {
      Blnce_CBL<-function(d,x,y)
      {
        count<-ifelse(x>y,1,0)
        return(count)
      }
      
      c1<-Blnce_CBL(d,d$CUR.BAL...HIST_01,d$CUR.BAL...HIST_02)
      c2<-Blnce_CBL(d,d$CUR.BAL...HIST_02,d$CUR.BAL...HIST_03)
      c3<-Blnce_CBL(d,d$CUR.BAL...HIST_03,d$CUR.BAL...HIST_04)
      c4<-Blnce_CBL(d,d$CUR.BAL...HIST_04,d$CUR.BAL...HIST_05)
      c5<-Blnce_CBL(d,d$CUR.BAL...HIST_05,d$CUR.BAL...HIST_06)
      c6<-Blnce_CBL(d,d$CUR.BAL...HIST_06,d$CUR.BAL...HIST_07)
      c1[is.na(c1)]<-0
      c2[is.na(c2)]<-0
      c3[is.na(c3)]<-0
      c4[is.na(c4)]<-0
      c5[is.na(c5)]<-0
      c6[is.na(c6)]<-0
      q<-c1+c2+c3+c4+c5+c6
      return(q)
    }
    d$balance_increase<-BBL(d)
    
    
    d3<-as.data.frame(d$balance_increase)
    d1<-as.data.frame(d$key)
    act<-cbind(d1,d3)
    colnames(act) <- c("KEY", "BALANCE_BUILDUP")
    return(act)
  }
  BALANCE_INCREASE<-Balance_buildup(d)
  
  ## colunts S04 in DAS...HIST columns and returns them as GOOD_IN_12MNTHS variable
  status<-function(d)
  {
    d<-within(d,dastwl<-paste(DAS...HIST_01,DAS...HIST_02,DAS...HIST_03,DAS...HIST_04,DAS...HIST_05,DAS...HIST_06,
                              DAS...HIST_07,DAS...HIST_08,DAS...HIST_09,DAS...HIST_10,DAS...HIST_11,DAS...HIST_12,sep=","))
    library(stringr )
    d$szerofour<-str_count(d$dastwl, "S04")
    d1<-as.data.frame(d$key)
    d3<-as.data.frame(d$szerofour)
    
    act<-cbind(d1,d3)
    colnames(act) <- c("KEY", "GOOD_IN_12MNTHS")
    return(act)
    
  }
  CLEANSTATUS_12MNTH<-status(d)
  
  
  ##gets CUR.BAL...HIST columns and applies linear regression to get current balance trend
  cbl_trend<-function(d)
  {
    d<-within(d,cbtwl<-paste(CUR.BAL...HIST_01,CUR.BAL...HIST_02,CUR.BAL...HIST_03,CUR.BAL...HIST_04,CUR.BAL...HIST_05,CUR.BAL...HIST_06,
                             CUR.BAL...HIST_07,CUR.BAL...HIST_08,CUR.BAL...HIST_09,CUR.BAL...HIST_10,CUR.BAL...HIST_11,CUR.BAL...HIST_12,sep=","))
    one = c(1:12)
    d$m<-paste(as.character(one), collapse=",")
    SLOPE<-function(data.frame=d,x,y)
    {
      var<-as.numeric(unlist(strsplit(x, split=",")))
      a<-cbind(var)
      a[is.na(a)]<-0
      k<-t(a)
      var<-as.numeric(k)
      mnth<-as.numeric(unlist(strsplit(y,split=",")))
      j<-cbind(var,mnth)
      j<-as.data.frame(j)
      l<-lm(j[,1]~j[,2])
      q<-l$coefficients[2]
      return(q)
    }
    for(i in 1:nrow(d))
    {
      d$cbltre[i]<-SLOPE(d,d$cbtwl[i],d$m[i])
    }
    
    d3<-as.data.frame(d$cbltre)
    d1<-as.data.frame(d$key)
    
    act<-cbind(d1,d3)
    
    
    colnames(act) <- c(  "KEY", "CBL_SLOPE_12MNTHS")
    return(act)
  }
  CURR_BAL_TREND<-cbl_trend(d)
  
  ## gets the AMT.OVERDUE columns and applies linear regresion to get the trend 
  overdue_trend<-function(d)
  {
    
    d<-within(d,odtwl<-paste(AMT.OVERDUE...HIST_01,AMT.OVERDUE...HIST_02,AMT.OVERDUE...HIST_03,AMT.OVERDUE...HIST_04,
                             AMT.OVERDUE...HIST_05,AMT.OVERDUE...HIST_06,AMT.OVERDUE...HIST_07,AMT.OVERDUE...HIST_08,AMT.OVERDUE...HIST_09,AMT.OVERDUE...HIST_10,AMT.OVERDUE...HIST_11,AMT.OVERDUE...HIST_12,sep=","))
    one = c(1:12)
    d$m<-paste(as.character(one), collapse=", ")
    
    SLOPE<-function(data.frame=d,x,y)
    {
      var<-as.numeric(unlist(strsplit(x, split=",")))
      a<-cbind(var)
      a[is.na(a)]<-0
      k<-t(a)
      var<-as.numeric(k)
      mnth<-as.numeric(unlist(strsplit(y,split=",")))
      j<-cbind(var,mnth)
      j<-as.data.frame(j)
      l<-lm(j[,1]~j[,2])
      q<-l$coefficients[2]
      return(q)
    }
    for(i in 1:nrow(d))
    {
      d$ovdtre[i]<-SLOPE(d,d$odtwl[i],d$m[i])
    }
    d$sno<-1:nrow(d)
    
    d2<-as.data.frame(d$ovdtre)
    d1<-as.data.frame(d$key)
    act<-cbind(d1,d2)
    colnames(act) <- c("KEY", "OVERDUE_AMOUNT_TREND")
    return(act)
  }
  OVERDUE_AMNT_TREND<-overdue_trend(d)
  
  ## gets the AMT.PAID columns and applies linear regresion to get the trend 
  amount_payment_trend<-function(d)
  {
    
    d<-within(d,pytwl<-paste(AMT.PAID...HIST_01,AMT.PAID...HIST_02,AMT.PAID...HIST_03,AMT.PAID...HIST_04,
                             AMT.PAID...HIST_05,AMT.PAID...HIST_06,AMT.PAID...HIST_07,AMT.PAID...HIST_08,AMT.PAID...HIST_09,AMT.PAID...HIST_10,AMT.PAID...HIST_11,AMT.PAID...HIST_12,sep=","))
    
    one = c(1:12)
    d$m<-paste(as.character(one), collapse=", ")
    
    SLOPE<-function(data.frame=d,x,y)
    {
      var<-as.numeric(unlist(strsplit(x, split=",")))
      a<-cbind(var)
      a[is.na(a)]<-0
      k<-t(a)
      var<-as.numeric(k)
      mnth<-as.numeric(unlist(strsplit(y,split=",")))
      j<-cbind(var,mnth)
      j<-as.data.frame(j)
      l<-lm(j[,1]~j[,2])
      q<-l$coefficients[2]
      return(q)
    }
    for(i in 1:nrow(d))
    {
      d$pmnttre[i]<-SLOPE(d,d$pytwl[i],d$m[i])
    }
    
    d1<-as.data.frame(d$key)
    d2<-as.data.frame(d$pmnttre)
    
    act<-cbind(d1,d2)
    colnames(act) <- c( "KEY", "AMNT_PAID_SLOPE_12MNTHS")
    return(act)
  }
  AMOUNT_PAYMENT_TREND<-amount_payment_trend(d)
  
  q<-Reduce(function(x, y) merge(x, y,by=c("KEY"), all=TRUE),list(CREDIT_LIMIT_TREND,PAYRATIO,CLEANSTATUS_12MNTH,BALANCE_INCREASE,CURR_BAL_TREND,BALANCE_SLOPE,OVERDUE_AMNT_TREND,AMOUNT_PAYMENT_TREND))
  return(q)
  
}




##reads in the intial file to determine the number of rows that we will need to loop through to execute. 
for(i in 1:length(list.files())){
  if(tools::file_ext(list.files()[i])== "csv"){
    file <- read.csv(list.files()[i], sep="|",header=T,colClasses=c("CANDIDATE...ID"="character","LOS.APP.ID"="character","DATE.REPORTED"="character"), nrows = 1)
    if((ncol(file) == 42 & colnames(file)[2] == "CANDIDATE...ID" & colnames(file)[3] == "LOS.APP.ID") | 
       (ncol(file) == 41 & colnames(file)[2] == "CANDIDATE...ID" & colnames(file)[3] == "LOS.APP.ID") | 
       (ncol(file) == 43 & colnames(file)[2] == "CANDIDATE...ID" & colnames(file)[3] == "LOS.APP.ID") |
       (ncol(file) == 40 & colnames(file)[2] == "CANDIDATE...ID" & colnames(file)[3] == "LOS.APP.ID")){
      
      dz <- read.csv(list.files()[i], sep="|",header=T,colClasses=c("NULL", NA,"NULL","NULL","NULL","NULL","NULL","NULL","NULL",
                                                                    "NULL","NULL","NULL","NULL","NULL","NULL","NULL","NULL","NULL",
                                                                    "NULL","NULL","NULL","NULL","NULL","NULL","NULL","NULL","NULL",
                                                                    "NULL","NULL","NULL","NULL","NULL","NULL","NULL","NULL","NULL",
                                                                    "NULL","NULL","NULL","NULL","NULL"), row.names = NULL)
      dy <- read.csv(list.files()[i], sep="|",header=T,colClasses=c("CANDIDATE...ID"="character","LOS.APP.ID"="character","DATE.REPORTED"="character"),  nrows = 1)
      
      rm(file)
      break
    } else if (i == length(list.files())){
      print("No Account file found!!")
    }
  }
}

## dff<-dff[dff$ACC.NUM=="XXXX",]

# df<-read.table("D:/Script/Post_Acq/Inquiry_Post_Acq.csv",sep="|",header=T,fill=T) ////Original
for(i in 1:length(list.files())){
  if(tools::file_ext(list.files()[i])== "csv"){
    file <- read.csv(list.files()[i], sep="|",header=T, fill = T, nrows = 1)
    if((ncol(file) == 32 & colnames(file)[2] == "LOS.APP.ID" & colnames(file)[3] == "BRANCH.ID") | 
       (ncol(file) == 33 & colnames(file)[2] == "LOS.APP.ID" & colnames(file)[3] == "BRANCH.ID") |
       (ncol(file) == 31 & colnames(file)[2] == "LOS.APP.ID" & colnames(file)[3] == "BRANCH.ID")){
      
      df <- read.csv(list.files()[i], sep="|",header=T, fill = T)
      rm(file)
      break
    } else if (i == length(list.files())){
      print("No Inquiry file found!!")
    }
  }
}
df$X<-NULL

##Run Date from Credit Rpt Id
run_date<-substr(df$CREDT.RPT.ID,5,10)
run_date<-unique(run_date)
run_date<-max(run_date)
run_date<-as.Date(as.character(run_date),"%y%m%d")

## Retro PR Date from Inquiry
retro_date<-unique(df$RETRO.PR.DT)
retro_date<-as.Date(paste(substr(retro_date,1,2),'-',substr(retro_date,4,5),'-',substr(retro_date,7,10), sep = ''),  format="%d-%m-%Y")

##Retro OR As-on-Run Date
date<-ifelse(is.na(retro_date),as.character(run_date),as.character(retro_date))
date<-as.Date(date)



#df1<-read.table("D:/Script/Post_Acq/Ioi_Post_Acq.csv",sep="|",header=T) /////Original
for(i in 1:length(list.files())){
  if(tools::file_ext(list.files()[i])== "csv"){
    file <- read.csv(list.files()[i], sep="|",header=T, nrows = 1)
    if((ncol(file) == 10 & colnames(file)[2] == "CUSTOMER.ID.MBR.ID" & colnames(file)[3] == "LOS.APP.ID")|
       (ncol(file) == 9 & colnames(file)[2] == "CUSTOMER.ID.MBR.ID" & colnames(file)[3] == "LOS.APP.ID")|
       (ncol(file) == 11 & colnames(file)[2] == "CUSTOMER.ID.MBR.ID" & colnames(file)[3] == "LOS.APP.ID")){
      
      df2 <- read.csv(list.files()[i], sep="|",header=T)
      rm(file)
      break
    } else if (i == length(list.files())){
      print("No Ioi file found!!")
    }
  }
}
df2$X<-NULL

#df2<-read.table("D:/Script/Post_Acq/Summary_Post_Acq.csv",sep="|",header=T) ////Original
for(i in 1:length(list.files())){
  if(tools::file_ext(list.files()[i])== "csv"){
    file <- read.csv(list.files()[i], sep="|",header=T, nrows = 1)
    if((ncol(file) == 28 & colnames(file)[2] == "CUSTOMER.ID.MBR.ID" & colnames(file)[3] == "LOS.APP.ID")|
       (ncol(file) == 27 & colnames(file)[2] == "CUSTOMER.ID.MBR.ID" & colnames(file)[3] == "LOS.APP.ID")|
       (ncol(file) == 26 & colnames(file)[2] == "CUSTOMER.ID.MBR.ID" & colnames(file)[3] == "LOS.APP.ID")){
      
      df1 <- read.table(list.files()[i], sep="|",header=T)
      rm(file)
      break
    } else if (i == length(list.files())){
      print("No Summary file found!!")
    }
  }
}
df1$X<-NULL

df2$INQUIRY.DATE<-as.Date(df2$INQUIRY.DATE,"%d-%m-%Y")
df2$Inquiries_6mnth<-ifelse(date-df2$INQUIRY.DATE>=0 & date-df2$INQUIRY.DATE<=180,1,0)
df3<-aggregate(df2$Inquiries_6mnth,list(crd=df2$CREDT.RPT.ID),sum)
colnames(df3)<-c("CREDT.RPT.ID","Inquiries_6mnth")




##formats the dates and aggrates to get the inquiries for last 6 months and aggregate them
# df$retro<-as.Date(df$RETRO.PR.DT,"%d-%m-%Y")
# df2$INQUIRY.DATE<-as.Date(df2$INQUIRY.DATE,"%d-%m-%Y")
# date<-na.omit(unique(df$retro))[1]
# df2$Inquiries_6mnth<-ifelse(date-df2$INQUIRY.DATE>=0 & date-df2$INQUIRY.DATE<=180,1,0)
# df3<-aggregate(df2$Inquiries_6mnth,list(crd=df2$CREDT.RPT.ID),sum)
# colnames(df3)<-c("CREDT.RPT.ID","Inquiries_6mnth")

##finds the column name and row number and records them
rownumber <- nrow(dz)
column.names <- colnames(dy)

## drops the whole data.frame so we will free up RAM to start execution.
rm(dz)
rm(dy)
gc()
counter = 1
row_counter = 0
print("data reading over")


while(counter <= ceiling(rownumber/100000)){
  print(counter)
  for(i in 1:length(list.files())){
    if(tools::file_ext(list.files()[i])== "csv"){
      file <- read.csv(list.files()[i], sep="|",header=T,
                       colClasses=c("CANDIDATE...ID"="character","LOS.APP.ID"=
                                      "character","DATE.REPORTED"="character"), nrows = 1)
      if((ncol(file) == 42 & colnames(file)[2] == "CANDIDATE...ID" & colnames(file)[3] == "LOS.APP.ID") | 
         (ncol(file) == 41 & colnames(file)[2] == "CANDIDATE...ID" & colnames(file)[3] == "LOS.APP.ID") | 
         (ncol(file) == 43 & colnames(file)[2] == "CANDIDATE...ID" & colnames(file)[3] == "LOS.APP.ID") |
         (ncol(file) == 40 & colnames(file)[2] == "CANDIDATE...ID" & colnames(file)[3] == "LOS.APP.ID")){
        
        dff <- read.csv(list.files()[i], sep="|",header=FALSE,colClasses=c("character","character","character","DATE.REPORTED"="character"), skip = 1 + row_counter, nrows = 100000)
        rm(file)
        break
      } else if (i == length(list.files())){
        print("No Account file found!!")
      }
    }
  }
  colnames(dff) <- column.names
  dff$X<-NULL
  dff<-dff[nchar(as.character(dff$REPORTED.DATE...HIST))>0,]
  
  #eliminate tradelines which do not have an update in the bureau since the last 3 years
  dff$DATE.REPORTED<-as.Date(dff$DATE.REPORTED,"%d-%m-%Y")
  dff$date_diff<-difftime(date,dff$DATE.REPORTED,unit="days")
  dff<-dff[dff$date_diff<=1080,]
  #dff$as.on.date<-NULL
  dff$date_diff<-NULL
  
  d <- mutate(dff, key1 = rownames(dff))
  d$key<-paste(d$CREDT.RPT.ID,d$key1,sep="-")
  
  
  
  icounter=1
  jcounter=20000
  
  repeat 
  {
    
    if(icounter>nrow(d))
    {
      break
    }
    
    else
    {
      if (jcounter>nrow(d))
      {
        jcounter=nrow(d)
        print("Last Batch")
        print(icounter)
        print(jcounter)
        final<-d[icounter:jcounter,]
        revised<-dataprep(final)
        o<-s(revised)
        o<-merge(revised,o,by.y=c("KEY"),by.x=c("key"))
        o<-subset(o,select=c(CREDT.RPT.ID:OCCUPATION,DAS...HIST_01:DAS...HIST_36,AMT.OVERDUE...HIST_01:AMNT_PAID_SLOPE_12MNTHS))
        o<-merge(o,df3,by=c("CREDT.RPT.ID"),all.x=T)
        o<-o[!duplicated(o),]
        names(o)[1:232]<-c("CREDT-RPT-ID","CANDIDATE - ID","LOS-APP-ID","CUSTOMER-ID-MBR-ID","BRANCH","KENDRA","SELF-INDICATOR","MATCH-TYPE","ACC-NUM","CREDIT-GRANTOR","ACCT-TYPE","CONTRIBUTOR-TYPE","DATE-REPORTED","OWNERSHIP-IND","ACCOUNT-STATUS","DISBURSED-DT","CLOSE-DT","LAST-PAYMENT-DATE","CREDIT-LIMIT/SANC-AMT","DISBURSED-AMT/HIGH-CREDIT","INSTALLMENT-AMT","CURRENT-BAL","INSTALLMENT-FREQUENCY","WRITE-OFF-DATE","OVERDUE-AMT","WRITE-OFF-AMT","ASSET_CLASS","ACCOUNT-REMARKS","LINKED-ACCOUNTS","INCOME","INCOME-INDICATOR","TENURE","OCCUPATION","DAS - HIST 1","DAS - HIST 2","DAS - HIST 3","DAS - HIST 4","DAS - HIST 5","DAS - HIST 6","DAS - HIST 7","DAS - HIST 8","DAS - HIST 9","DAS - HIST 10","DAS - HIST 11","DAS - HIST 12","DAS - HIST 13","DAS - HIST 14","DAS - HIST 15","DAS - HIST 16","DAS - HIST 17","DAS - HIST 18","DAS - HIST 19","DAS - HIST 20","DAS - HIST 21","DAS - HIST 22","DAS - HIST 23","DAS - HIST 24","DAS - HIST 25","DAS - HIST 26","DAS - HIST 27","DAS - HIST 28","DAS - HIST 29","DAS - HIST 30","DAS - HIST 31","DAS - HIST 32","DAS - HIST 33","DAS - HIST 34","DAS - HIST 35","DAS - HIST 36","OVR-AMT-HIST 1","OVR-AMT-HIST 2","OVR-AMT-HIST 3","OVR-AMT-HIST 4","OVR-AMT-HIST 5","OVR-AMT-HIST 6","OVR-AMT-HIST 7","OVR-AMT-HIST 8","OVR-AMT-HIST 9","OVR-AMT-HIST 10","OVR-AMT-HIST 11","OVR-AMT-HIST 12","OVR-AMT-HIST 13","OVR-AMT-HIST 14","OVR-AMT-HIST 15","OVR-AMT-HIST 16","OVR-AMT-HIST 17","OVR-AMT-HIST 18","OVR-AMT-HIST 19","OVR-AMT-HIST 20","OVR-AMT-HIST 21","OVR-AMT-HIST 22","OVR-AMT-HIST 23","OVR-AMT-HIST 24","OVR-AMT-HIST 25","OVR-AMT-HIST 26","OVR-AMT-HIST 27","OVR-AMT-HIST 28","OVR-AMT-HIST 29","OVR-AMT-HIST 30","OVR-AMT-HIST 31","OVR-AMT-HIST 32","OVR-AMT-HIST 33","OVR-AMT-HIST 34","OVR-AMT-HIST 35","OVR-AMT-HIST 36","HIGH CRD - HIST 1","HIGH CRD - HIST 2","HIGH CRD - HIST 3","HIGH CRD - HIST 4","HIGH CRD - HIST 5","HIGH CRD - HIST 6","HIGH CRD - HIST 7","HIGH CRD - HIST 8","HIGH CRD - HIST 9","HIGH CRD - HIST 10","HIGH CRD - HIST 11","HIGH CRD - HIST 12","HIGH CRD - HIST 13","HIGH CRD - HIST 14","HIGH CRD - HIST 15","HIGH CRD - HIST 16","HIGH CRD - HIST 17","HIGH CRD - HIST 18","HIGH CRD - HIST 19","HIGH CRD - HIST 20","HIGH CRD - HIST 21","HIGH CRD - HIST 22","HIGH CRD - HIST 23","HIGH CRD - HIST 24","HIGH CRD - HIST 25","HIGH CRD - HIST 26","HIGH CRD - HIST 27","HIGH CRD - HIST 28","HIGH CRD - HIST 29","HIGH CRD - HIST 30","HIGH CRD - HIST 31","HIGH CRD - HIST 32","HIGH CRD - HIST 33","HIGH CRD - HIST 34","HIGH CRD - HIST 35","HIGH CRD - HIST 36","CUR BAL - HIST 1","CUR BAL - HIST 2","CUR BAL - HIST 3","CUR BAL - HIST 4","CUR BAL - HIST 5","CUR BAL - HIST 6","CUR BAL - HIST 7","CUR BAL - HIST 8","CUR BAL - HIST 9","CUR BAL - HIST 10","CUR BAL - HIST 11","CUR BAL - HIST 12","CUR BAL - HIST 13","CUR BAL - HIST 14","CUR BAL - HIST 15","CUR BAL - HIST 16","CUR BAL - HIST 17","CUR BAL - HIST 18","CUR BAL - HIST 19","CUR BAL - HIST 20","CUR BAL - HIST 21","CUR BAL - HIST 22","CUR BAL - HIST 23","CUR BAL - HIST 24","CUR BAL - HIST 25","CUR BAL - HIST 26","CUR BAL - HIST 27","CUR BAL - HIST 28","CUR BAL - HIST 29","CUR BAL - HIST 30","CUR BAL - HIST 31","CUR BAL - HIST 32","CUR BAL - HIST 33","CUR BAL - HIST 34","CUR BAL - HIST 35","CUR BAL - HIST 36","DATE - HIST 1","DATE - HIST 2","DATE - HIST 3","DATE - HIST 4","DATE - HIST 5","DATE - HIST 6","DATE - HIST 7","DATE - HIST 8","DATE - HIST 9","DATE - HIST 10","DATE - HIST 11","DATE - HIST 12","DATE - HIST 13","DATE - HIST 14","DATE - HIST 15","DATE - HIST 16","DATE - HIST 17","DATE - HIST 18","DATE - HIST 19","DATE - HIST 20","DATE - HIST 21","DATE - HIST 22","DATE - HIST 23","DATE - HIST 24","DATE - HIST 25","DATE - HIST 26","DATE - HIST 27","DATE - HIST 28","DATE - HIST 29","DATE - HIST 30","DATE - HIST 31","DATE - HIST 32","DATE - HIST 33","DATE - HIST 34","DATE - HIST 35","DATE - HIST 36","PYMT-HIST 1","PYMT-HIST 2","PYMT-HIST 3","PYMT-HIST 4","PYMT-HIST 5","PYMT-HIST 6","PYMT-HIST 7","PYMT-HIST 8","PYMT-HIST 9","PYMT-HIST 10","PYMT-HIST 11","PYMT-HIST 12","PYMT-HIST 13","PYMT-HIST 14","PYMT-HIST 15","PYMT-HIST 16","PYMT-HIST 17","PYMT-HIST 18","PYMT-HIST 19")
        names(o)[233:294]<-c("PYMT-HIST 20","PYMT-HIST 21","PYMT-HIST 22","PYMT-HIST 23","PYMT-HIST 24","PYMT-HIST 25","PYMT-HIST 26","PYMT-HIST 27","PYMT-HIST 28","PYMT-HIST 29","PYMT-HIST 30","PYMT-HIST 31","PYMT-HIST 32","PYMT-HIST 33","PYMT-HIST 34","PYMT-HIST 35","PYMT-HIST 36","AMT PAID - HIST 1","AMT PAID - HIST 2","AMT PAID - HIST 3","AMT PAID - HIST 4","AMT PAID - HIST 5","AMT PAID - HIST 6","AMT PAID - HIST 7","AMT PAID - HIST 8","AMT PAID - HIST 9","AMT PAID - HIST 10","AMT PAID - HIST 11","AMT PAID - HIST 12","AMT PAID - HIST 13","AMT PAID - HIST 14","AMT PAID - HIST 15","AMT PAID - HIST 16","AMT PAID - HIST 17","AMT PAID - HIST 18","AMT PAID - HIST 19","AMT PAID - HIST 20","AMT PAID - HIST 21","AMT PAID - HIST 22","AMT PAID - HIST 23","AMT PAID - HIST 24","AMT PAID - HIST 25","AMT PAID - HIST 26","AMT PAID - HIST 27","AMT PAID - HIST 28","AMT PAID - HIST 29","AMT PAID - HIST 30","AMT PAID - HIST 31","AMT PAID - HIST 32","AMT PAID - HIST 33","AMT PAID - HIST 34","AMT PAID - HIST 35","AMT PAID - HIST 36","CREDIT_LIMIT_SLOPE_12MNTHS","PAY_RATIO","GOOD_IN_12MNTHS","BALANCE_BUILDUP","CBL_SLOPE_12MNTHS","BALANCE_SLOPE","OVERDUE_AMOUNT_TREND","AMNT_PAID_SLOPE_12MNTHS","Inquiries_6mnth")
        
        
        ##write.table(o,"D:/Script/Post_Acq/Post_Acq_Output.csv",sep = "|",
        ##append = TRUE,row.names = FALSE,col.names = FALSE)
        # write output data frame to flat file
        if (!file.exists("Setting")){
          dir.create("Setting")
        }
        setwd(".//Setting")
        
        write.table(o,paste(counter,"LastBatch",".csv", sep = ""),sep="|",
                    row.names = FALSE, col.names = TRUE)
        setwd("..")
        
        icounter=icounter+20000
        jcounter=jcounter+20000
        
        print("End of Last Batch")
        print(Sys.time())
        
      } 
      else
      {		
        final<-d[icounter:jcounter,]
        revised<-dataprep(final)
        o<-s(revised)
        o<-merge(revised,o,by.y=c("KEY"),by.x=c("key"))
        o<-subset(o,select=c(CREDT.RPT.ID:OCCUPATION,DAS...HIST_01:DAS...HIST_36,
                             AMT.OVERDUE...HIST_01:AMNT_PAID_SLOPE_12MNTHS))
        o<-merge(o,df3,by=c("CREDT.RPT.ID"),all.x=T)
        o<-o[!duplicated(o),]
        names(o)[1:232]<-c("CREDT-RPT-ID","CANDIDATE - ID","LOS-APP-ID","CUSTOMER-ID-MBR-ID","BRANCH","KENDRA","SELF-INDICATOR","MATCH-TYPE","ACC-NUM","CREDIT-GRANTOR","ACCT-TYPE","CONTRIBUTOR-TYPE","DATE-REPORTED","OWNERSHIP-IND","ACCOUNT-STATUS","DISBURSED-DT","CLOSE-DT","LAST-PAYMENT-DATE","CREDIT-LIMIT/SANC-AMT","DISBURSED-AMT/HIGH-CREDIT","INSTALLMENT-AMT","CURRENT-BAL","INSTALLMENT-FREQUENCY","WRITE-OFF-DATE","OVERDUE-AMT","WRITE-OFF-AMT","ASSET_CLASS","ACCOUNT-REMARKS","LINKED-ACCOUNTS","INCOME","INCOME-INDICATOR","TENURE","OCCUPATION","DAS - HIST 1","DAS - HIST 2","DAS - HIST 3","DAS - HIST 4","DAS - HIST 5","DAS - HIST 6","DAS - HIST 7","DAS - HIST 8","DAS - HIST 9","DAS - HIST 10","DAS - HIST 11","DAS - HIST 12","DAS - HIST 13","DAS - HIST 14","DAS - HIST 15","DAS - HIST 16","DAS - HIST 17","DAS - HIST 18","DAS - HIST 19","DAS - HIST 20","DAS - HIST 21","DAS - HIST 22","DAS - HIST 23","DAS - HIST 24","DAS - HIST 25","DAS - HIST 26","DAS - HIST 27","DAS - HIST 28","DAS - HIST 29","DAS - HIST 30","DAS - HIST 31","DAS - HIST 32","DAS - HIST 33","DAS - HIST 34","DAS - HIST 35","DAS - HIST 36","OVR-AMT-HIST 1","OVR-AMT-HIST 2","OVR-AMT-HIST 3","OVR-AMT-HIST 4","OVR-AMT-HIST 5","OVR-AMT-HIST 6","OVR-AMT-HIST 7","OVR-AMT-HIST 8","OVR-AMT-HIST 9","OVR-AMT-HIST 10","OVR-AMT-HIST 11","OVR-AMT-HIST 12","OVR-AMT-HIST 13","OVR-AMT-HIST 14","OVR-AMT-HIST 15","OVR-AMT-HIST 16","OVR-AMT-HIST 17","OVR-AMT-HIST 18","OVR-AMT-HIST 19","OVR-AMT-HIST 20","OVR-AMT-HIST 21","OVR-AMT-HIST 22","OVR-AMT-HIST 23","OVR-AMT-HIST 24","OVR-AMT-HIST 25","OVR-AMT-HIST 26","OVR-AMT-HIST 27","OVR-AMT-HIST 28","OVR-AMT-HIST 29","OVR-AMT-HIST 30","OVR-AMT-HIST 31","OVR-AMT-HIST 32","OVR-AMT-HIST 33","OVR-AMT-HIST 34","OVR-AMT-HIST 35","OVR-AMT-HIST 36","HIGH CRD - HIST 1","HIGH CRD - HIST 2","HIGH CRD - HIST 3","HIGH CRD - HIST 4","HIGH CRD - HIST 5","HIGH CRD - HIST 6","HIGH CRD - HIST 7","HIGH CRD - HIST 8","HIGH CRD - HIST 9","HIGH CRD - HIST 10","HIGH CRD - HIST 11","HIGH CRD - HIST 12","HIGH CRD - HIST 13","HIGH CRD - HIST 14","HIGH CRD - HIST 15","HIGH CRD - HIST 16","HIGH CRD - HIST 17","HIGH CRD - HIST 18","HIGH CRD - HIST 19","HIGH CRD - HIST 20","HIGH CRD - HIST 21","HIGH CRD - HIST 22","HIGH CRD - HIST 23","HIGH CRD - HIST 24","HIGH CRD - HIST 25","HIGH CRD - HIST 26","HIGH CRD - HIST 27","HIGH CRD - HIST 28","HIGH CRD - HIST 29","HIGH CRD - HIST 30","HIGH CRD - HIST 31","HIGH CRD - HIST 32","HIGH CRD - HIST 33","HIGH CRD - HIST 34","HIGH CRD - HIST 35","HIGH CRD - HIST 36","CUR BAL - HIST 1","CUR BAL - HIST 2","CUR BAL - HIST 3","CUR BAL - HIST 4","CUR BAL - HIST 5","CUR BAL - HIST 6","CUR BAL - HIST 7","CUR BAL - HIST 8","CUR BAL - HIST 9","CUR BAL - HIST 10","CUR BAL - HIST 11","CUR BAL - HIST 12","CUR BAL - HIST 13","CUR BAL - HIST 14","CUR BAL - HIST 15","CUR BAL - HIST 16","CUR BAL - HIST 17","CUR BAL - HIST 18","CUR BAL - HIST 19","CUR BAL - HIST 20","CUR BAL - HIST 21","CUR BAL - HIST 22","CUR BAL - HIST 23","CUR BAL - HIST 24","CUR BAL - HIST 25","CUR BAL - HIST 26","CUR BAL - HIST 27","CUR BAL - HIST 28","CUR BAL - HIST 29","CUR BAL - HIST 30","CUR BAL - HIST 31","CUR BAL - HIST 32","CUR BAL - HIST 33","CUR BAL - HIST 34","CUR BAL - HIST 35","CUR BAL - HIST 36","DATE - HIST 1","DATE - HIST 2","DATE - HIST 3","DATE - HIST 4","DATE - HIST 5","DATE - HIST 6","DATE - HIST 7","DATE - HIST 8","DATE - HIST 9","DATE - HIST 10","DATE - HIST 11","DATE - HIST 12","DATE - HIST 13","DATE - HIST 14","DATE - HIST 15","DATE - HIST 16","DATE - HIST 17","DATE - HIST 18","DATE - HIST 19","DATE - HIST 20","DATE - HIST 21","DATE - HIST 22","DATE - HIST 23","DATE - HIST 24","DATE - HIST 25","DATE - HIST 26","DATE - HIST 27","DATE - HIST 28","DATE - HIST 29","DATE - HIST 30","DATE - HIST 31","DATE - HIST 32","DATE - HIST 33","DATE - HIST 34","DATE - HIST 35","DATE - HIST 36","PYMT-HIST 1","PYMT-HIST 2","PYMT-HIST 3","PYMT-HIST 4","PYMT-HIST 5","PYMT-HIST 6","PYMT-HIST 7","PYMT-HIST 8","PYMT-HIST 9","PYMT-HIST 10","PYMT-HIST 11","PYMT-HIST 12","PYMT-HIST 13","PYMT-HIST 14","PYMT-HIST 15","PYMT-HIST 16","PYMT-HIST 17","PYMT-HIST 18","PYMT-HIST 19")
        names(o)[233:294]<-c("PYMT-HIST 20","PYMT-HIST 21","PYMT-HIST 22","PYMT-HIST 23","PYMT-HIST 24","PYMT-HIST 25","PYMT-HIST 26","PYMT-HIST 27","PYMT-HIST 28","PYMT-HIST 29","PYMT-HIST 30","PYMT-HIST 31","PYMT-HIST 32","PYMT-HIST 33","PYMT-HIST 34","PYMT-HIST 35","PYMT-HIST 36","AMT PAID - HIST 1","AMT PAID - HIST 2","AMT PAID - HIST 3","AMT PAID - HIST 4","AMT PAID - HIST 5","AMT PAID - HIST 6","AMT PAID - HIST 7","AMT PAID - HIST 8","AMT PAID - HIST 9","AMT PAID - HIST 10","AMT PAID - HIST 11","AMT PAID - HIST 12","AMT PAID - HIST 13","AMT PAID - HIST 14","AMT PAID - HIST 15","AMT PAID - HIST 16","AMT PAID - HIST 17","AMT PAID - HIST 18","AMT PAID - HIST 19","AMT PAID - HIST 20","AMT PAID - HIST 21","AMT PAID - HIST 22","AMT PAID - HIST 23","AMT PAID - HIST 24","AMT PAID - HIST 25","AMT PAID - HIST 26","AMT PAID - HIST 27","AMT PAID - HIST 28","AMT PAID - HIST 29","AMT PAID - HIST 30","AMT PAID - HIST 31","AMT PAID - HIST 32","AMT PAID - HIST 33","AMT PAID - HIST 34","AMT PAID - HIST 35","AMT PAID - HIST 36","CREDIT_LIMIT_SLOPE_12MNTHS","PAY_RATIO","GOOD_IN_12MNTHS","BALANCE_BUILDUP","CBL_SLOPE_12MNTHS","BALANCE_SLOPE","OVERDUE_AMOUNT_TREND","AMNT_PAID_SLOPE_12MNTHS","Inquiries_6mnth")
        
        if(icounter==1)
        {
          print("First Batch")
          print(icounter)
          print(jcounter)
          ##write.table(o,"D:/Script/Post_Acq/Post_Acq_Output.csv",sep = "|",
          ##append = FALSE,row.names = FALSE,col.names = TRUE)
          if (!file.exists("Setting")){
            dir.create("Setting")
          }
          setwd(".//Setting")
          
          write.table(o,paste(counter,"FirstBatch",".csv", sep = ""),sep="|",
                      row.names = FALSE, col.names = TRUE)
          setwd("..")
          
          print("End of First Batch")
          print(Sys.time())
          
        }
        else
        {
          print("Intermediate Iteration")
          print(icounter)
          print(jcounter)
          ##write.table(o,"D:/Script/Post_Acq/Post_Acq_Output.csv",sep = "|",
          ##append = TRUE,row.names = FALSE,col.names = FALSE)
          if (!file.exists("Setting")){
            dir.create("Setting")
          }
          setwd(".//Setting")
          
          write.table(o,paste(counter,"IntBatch",icounter,".csv", sep = ""),
                      sep="|",row.names = FALSE, col.names = TRUE)
          
          setwd("..")
          
          print("End of Iteration")
          print(Sys.time())
          
        }
        icounter=icounter+20000
        jcounter=jcounter+20000
      }
    }		
  }
  counter = counter + 1
  
  row_counter = row_counter + 100000
}

setwd(".//Setting")
settingfolder <- getwd()
final <- data.frame()
for(file in 1:length(list.files())){
  newfile <- read.csv(list.files()[file], sep = "|", header = TRUE, 
                      stringsAsFactors =FALSE, colClasses=c("CANDIDATE...ID"=
                                                              "character",
                                                            "LOS.APP.ID"=
                                                              "character"))
  
  newfile$BRANCH <- ifelse(is.na(newfile$BRANCH), "",newfile$BRANCH)
  newfile$KENDRA <- ifelse(is.na(newfile$KENDRA), "",newfile$KENDRA)
  
  final <- plyr::rbind.fill(final, newfile)
}

## deletes the auxiallary folder.
# setwd("..")
# unlink("Setting")

# sets the wd to output location we defined and save with the chosen name.
setwd("..")
setwd("..")

if (!file.exists("Output")){
  dir.create("Output")
}
setwd(".//Output")
final <- unique(final)

write.table(final,file = output_name,sep="|",row.names = FALSE)
print(Sys.time())
setwd(settingfolder)
setwd("..")
rm(list = ls())
unlink("Setting", recursive = TRUE)
