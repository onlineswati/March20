print(Sys.time())
options(scipen=999)

library(data.table)
library(dplyr)
library(stringr)
library(splitstackshape)
library(lazyeval)

#Input Data
#Inq_Attr_R<-read.table("E:/SBI Cards v2/Final Scripts/Inquiry_Attributes_Temp.csv",sep="|",header=T,colClasses=c("LOS.APP.ID"="character"),fill=T)
 Inq_Attr_R<-read.table("/home/ubuntu/data/Project/temp/Inquiry_Attributes_Post_Acq.csv",sep="|",header=T,colClasses=c("LOS.APP.ID"="character"),fill=T)
print(nrow(Inq_Attr_R))

Inq_Attr_awk_set1<-read.table("/home/ubuntu/data/Project/temp/Inquiry_Attribute_part_1.csv",sep="|",header=T,fill=T)
print(nrow(Inq_Attr_awk_set1))

Inq_Attr_awk_set2<-read.table("/home/ubuntu/data/Project/temp/Inquiry_Attribute_part_2.csv",sep="|",header=T,fill=T)
print(nrow(Inq_Attr_awk_set2))

Inq_Attr_awk_set3<-read.table("/home/ubuntu/data/Project/temp/Inquiry_Attribute_part_3.csv",sep="|",header=T,fill=T)
print(nrow(Inq_Attr_awk_set3))

Inq_Attr_awk_set4<-read.table("/home/ubuntu/data/Project/temp/Inquiry_Attribute_part_4.csv",sep="|",header=T,fill=T)
print(nrow(Inq_Attr_awk_set4))

Inq_Attr_Final<-merge(Inq_Attr_R,Inq_Attr_awk_set1, by="CREDT.RPT.ID",all=T)
print(nrow(Inq_Attr_Final))

Inq_Attr_Final<-merge(Inq_Attr_Final,Inq_Attr_awk_set2, by="CREDT.RPT.ID",all=T) 
print(nrow(Inq_Attr_Final))

Inq_Attr_Final<-merge(Inq_Attr_Final,Inq_Attr_awk_set3, by="CREDT.RPT.ID",all=T) 
print(nrow(Inq_Attr_Final))

Inq_Attr_Final<-merge(Inq_Attr_Final,Inq_Attr_awk_set4, by="CREDT.RPT.ID",all=T) 
print(nrow(Inq_Attr_Final))

Inq_Attr_Final<-Inq_Attr_Final[Inq_Attr_Final$CREDT.RPT.ID!="CREDT-RPT-ID",]

write.table(Inq_Attr_Final,"/home/ubuntu/data/Project/Output/Inquiry_Attributes_Post_Acq.csv",sep="|",row.names = FALSE)

print(Sys.time())
gc()
rm(list=ls(all=TRUE))
